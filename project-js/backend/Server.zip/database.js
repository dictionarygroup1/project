module.exports = {
    db: 'mongodb+srv://benzkittisak:kittisak077@cluster0.8dfal.mongodb.net/vue?authSource=admin&replicaSet=atlas-r9c0eb-shard-0&w=majority&readPreference=primary&appname=MongoDB%20Compass&retryWrites=true&ssl=true'
}